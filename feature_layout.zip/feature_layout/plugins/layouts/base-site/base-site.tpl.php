<div id="page">
	<header>
		<div class="grid-container">
			<div class="grid-100 tablet-grid-100 mobile-grid-100 grid-parent">
				<div class="grid-15 tablet-grid-15 mobile-grid-60 mobile-prefix-20 mobile-suffix-20 grid-parent"><?php print $content['logo']; ?></div>
				<div class="grid-85 tablet-grid-85 mobile-grid-100 grid-parent"><?php print $content['menu']; ?></div>
			</div>
		</div>
	</header>
	<main>
		<div class="main-content"><?php print $content['main_content']; ?></div>
	</main>
	<footer>
		<div class="grid-container">
			<div class="grid-100 tablet-grid-100 mobile-grid-100">
				<div class="border-top">
					<div class="grid-35 tablet-grid-35 mobile-grid-100 grid-parent"><?php print $content['footer_logo']; ?></div>
					<div class="grid-65 tablet-grid-65 mobile-grid-100 grid-parent right"><?php print $content['footer_copyright']; ?></div>
				</div>
			</div>
			<div class="grid-100 tablet-grid-100 mobile-grid-100 grid-parent">
				<div class="grid-80 tablet-grid-80 mobile-grid-100 right"><?php print $content['footer_menu']; ?></div>
				<div class="grid-20 tablet-grid-20 mobile-grid-100"><?php print $content['footer_newsletter']; ?></div>
			</div>
		</div>
	</footer>
</div>