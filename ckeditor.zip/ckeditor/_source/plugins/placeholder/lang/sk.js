﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'placeholder', 'sk',
{
	placeholder :
	{
		title		: 'Vlastnosti placeholdera',
		toolbar		: 'Vytvoriť placeholder',
		text		: 'Text placeholdera',
		edit		: 'Upraviť placeholder',
		textMissing	: 'Placeholder musí obsahovať text.'
	}
});
