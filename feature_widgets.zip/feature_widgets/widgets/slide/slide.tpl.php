<div class="flexslider <?php print $id_flexslider; ?>">
	<ul class="slides">
		<?php foreach ($slides as $slide): ?>
		<li class="slide <?php print $slide->clases; ?>">
			<?php //echo "<pre>"; print_r($slide); echo "</pre>";
			$content = $slide->image . '<div class="caption"><div class="title">' . $slide->title . '</div><div>' . $slide->description . '</div>' . $slide->titleLink . '</div>';
			if($slide->type == 1) {
				!empty($slide->link)? print l($content, $slide->link, array('html' => TRUE)) : print $content;
			} else { ?>
				<video id="example_video_1" class="video-js vjs-default-skin" controls preload="auto" poster="<?php !is_null($slide->video_preview) ? print $slide->video_preview : ''; ?>" data-setup='{"example_option":true}'>
					<?php foreach($slide->video as $video_key => $video): ?>
						<?php if($video['filemime'] !== 'image/jpeg'): ?>
							<source src="<?php print file_create_url($video['uri']); ?>" type='<?php print $video['filemime']; ?>' />
						<?php endif; ?>
					<?php endforeach; ?>
				</video>
			<?php } ?>
		</li>
		<?php endforeach; ?>
	</ul>
</div>