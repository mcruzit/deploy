<div id="twitter_timeline" class="feature_widgets scroll-pane">
  <?php print $title; ?>
  <?php foreach($twitter_timeline as $tweet): ?>
  <div class="tweet"><?php print $tweet; ?></div>
  <?php endforeach; ?>
  <div class="buttons">
    <?php print $btn_tweet . $btn_follow; ?>
  </div>
</div>