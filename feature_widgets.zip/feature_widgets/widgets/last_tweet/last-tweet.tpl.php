<div class="last-tweet-image"><?php print $image; ?></div>
<div class="last-tweet-username"><?php print $username; ?></div>
<div class="last-tweet-message"><?php print $message; ?></div>
<div class="last-tweet-follow"><?php print $follow; ?></div>