function alto(altoIframe) {
	setTimeout(function(){
	    var frame = altoIframe;
	    frame.height = 22;
	    var content = (frame.contentWindow || frame.contentDocument);
	    frame.height = content.document.body.scrollHeight;
	}, 1000);
}
var id = Drupal.settings.id;
var elemento = document.getElementById(id);
elemento.onload = function(){
	alto(elemento);
}
window.onresize = function(){
	alto(elemento);
};