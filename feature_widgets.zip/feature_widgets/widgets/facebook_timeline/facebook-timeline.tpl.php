<div id="facebook_timeline" class="feature_widgets scroll-pane">
  <?php print $title; ?>
  <div class="wrapper">
    <?php foreach($facebook_timeline as $item): ?>
    <div class="post">
      <?php
      print $item->created_time;
      print $item->story;
      print $item->name;
      print $item->message;
      print $item->link;
      ?>
    </div>
    <?php endforeach; ?>
  </div>
  <?php print $like; ?>
</div>