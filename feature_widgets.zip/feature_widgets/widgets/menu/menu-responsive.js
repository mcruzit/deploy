function menuSelect(id) {
	var id = "#" + id + ".select-menu";
	jQuery("<select />").appendTo(id);
	jQuery("<option />", {
		"selected": "selected",
		"value"   : "",
		"text"    : "Selecciona un item"
	}).appendTo(id + " select");
	jQuery(id + " ul.menu li a").each(function() {
		var el = jQuery(this);
		jQuery("<option />", {
			"value"   : el.attr("href"),
			"text"    : el.text()
		}).appendTo(id + " select");
	});
	jQuery(id + " select").change(function() {
		window.location = jQuery(this).find("option:selected").val();
	});
	jQuery(window).resize(function() {
		if(jQuery(window).width() < 768) {
			jQuery(id + " > select").css('display', 'block');
			jQuery(id + " > ul.menu").css('display', 'none');
		} else {
			jQuery(id + " > select").css('display', 'none');
			jQuery(id + " > ul.menu").css('display', 'block');
		}
	});
}
