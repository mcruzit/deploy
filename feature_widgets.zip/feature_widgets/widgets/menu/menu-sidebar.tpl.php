<div id="<?php print $menu[0]['id']; ?>" class="menu-mobile-sidebar menu-display-<?php print $menu[0]['display']; ?>">
	<div id="<?php print $menu[0]['id'] . ' ' . $menu[0]['childs']; ?>-top">
		<?php print l('menu', '', array('fragment' => $menu[0]['id'] . '-nav', 'external' => true, 'attributes' => array('id' => $menu[0]['id'] . '-nav-open-btn', 'class' => 'nav-btn', 'onclick' => "document.getElementsByTagName('html')[0].classList.add('js-nav');"))); ?>
	</div>
	<div id="<?php print $menu[0]['id']; ?>-nav" class="menu-navigation <?php print $menu[0]['dropdown']; ?>">
		<?php print l('cerrar', '', array('fragment' => $menu[0]['id'] . '-top', 'external' => true, 'attributes' => array('id' => $menu[0]['id'] . '-nav-close-btn', 'class' => 'close-btn', 'onclick' => "document.getElementsByTagName('html')[0].classList.remove('js-nav');"))); ?>
		<?php print drupal_render($menu[0]['menu']); ?>
	</div>
</div>
