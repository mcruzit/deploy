<div id="<?php print $menu[0]['id']; ?>" class="<?php print $menu[0]['type']; ?> menu-display-<?php print $menu[0]['display']; ?>">
	<div class="<?php print $menu[0]['dropdown'] . ' ' . $menu[0]['childs']; ?>">
		<?php print drupal_render($menu[0]['menu']); ?>
	</div>
</div>
