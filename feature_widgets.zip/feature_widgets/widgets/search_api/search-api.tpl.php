<div id="search-results">
<?php !empty($search_string) ? print '<h1 class="pane-title">' . t('Resultados para ') . '"'. $search_string .'"</h1>' : '';
if(!empty($search_result)){ ?>
	<ul class="grid-100 grid-parent">
		<?php foreach(array_chunk($search_result, 5, false) as $results){ ?>
		<div class="clearfix">
		<?php foreach($results as $result){ ?>
			<li class="grid-20 mobile-grid-100">
				<a title="<?php print $result['title']; ?>" alt="<?php print $result['title']; ?>" href="<?php print $result['url']; ?>" class="content">
					<?php print $result['title']; ?>
				</a>
			</li>
		<?php } ?>
		</div>
		<?php } ?>
	</ul>

	<?php print theme('pager');
} else { ?>
  <div id="empty_search"><?php print $search_empty; ?></div>
<?php } ?>

</div>
