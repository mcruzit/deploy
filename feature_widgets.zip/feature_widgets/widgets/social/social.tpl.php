<ul class="social-profiles-list social-profiles-list-<?php echo $social_style; ?>">
	<?php foreach( $social_profiles as $key => $profile ) { ?>
	<li class="item-list item-list-<?php echo $key; ?>"><a href="<?php echo $profile; ?>"><?php echo $profile; ?></a></li>
<?php } ?>
</ul>