<?php
if (isset($comments['list'][0])):
?>
<div class="total"><?php print $comments['total'] .' '. t('comments');?></div>
<div class="comments">
<?php
foreach($comments['list'] as $comment){
  print '<div class="comment">';
  print '<div class="name">'.$comment['name'].'</div>';
  print '<div class="body">'.$comment['body'].'</div>';
  print '<div class="date">'.$comment['date'].'</div>';
  print '</div>';
}
?>
</div>
<?php
endif;
print $form;
?>
