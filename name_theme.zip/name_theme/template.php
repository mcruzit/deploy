<?php
/**
 * @file
 * The primary PHP file for this theme.
 */
function name_theme_preprocess_html(&$variables) {
  //drupal_add_css("//fonts.googleapis.com/css?family=Montserrat:400,700", array("type" => "external"));
}